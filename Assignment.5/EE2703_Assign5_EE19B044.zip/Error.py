# Errors
errors[i]=(abs(phi-oldphi)).max()