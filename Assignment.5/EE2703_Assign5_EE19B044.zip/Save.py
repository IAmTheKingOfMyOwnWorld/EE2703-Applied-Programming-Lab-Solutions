# Copying phi
oldphi=phi.copy()