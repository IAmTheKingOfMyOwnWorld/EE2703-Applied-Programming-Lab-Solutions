# Function To Assert Boundaries
def boundary(phi,index):
    phi[1:-1,0]=phi[1:-1,1]
    phi[0,1:-1]=phi[1,1:-1]
    phi[1:-1,-1]=phi[1:-1,-2]
    phi[-1,1:-1]=0
    phi[index]=1.0
    return phi