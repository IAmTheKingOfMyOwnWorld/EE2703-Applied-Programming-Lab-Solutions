# Function To Evaluate The Parameter Of An Exponent
def error(a,b):]
    logb=np.log(b)]
    vec=np.zeros((len(a),2))
    vec[:,0]=a
    vec[:,1]=1
    B,logA=np.linalg.lstsq(vec,np.transpose(logb))[0]]
    return (np.exp(logA),B)