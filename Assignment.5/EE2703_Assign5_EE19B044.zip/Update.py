# Function To Update phi
def update(phi,oldpfi):
    phi[1:-1,1:-1]=0.25*(oldphi[0:-2,1:-1]+oldphi[2:,1:-1]
                        +oldphi[1:-1,0:-2]+oldphi[1:-1,2:])
    return phi